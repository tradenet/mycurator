<?php
//Start the cloud process file
include("mycurator_cloud_process.php");
//
?>