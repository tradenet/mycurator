<?php
//Set Database Globals

define('CS_SERVER','localhost');
define('CS_USER','u6n478r2ct2qy');
define('CS_PWD', '669728@Mt');
define('CS_DB','tgaitest_target-info');
//$cs_db = 'target-info';
//

//Set log path for pageworkers
define('FPATH','/home/customer/www/tgtinfo.net/public_html/');      //  /var/log/tgtinfo.net/';



